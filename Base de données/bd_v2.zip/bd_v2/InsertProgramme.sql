-- Insertion des programmes
INSERT INTO DevisMinistere (annee, codeSpecialisation, nbUnite, specialisation, nbHeurefrmGenerale, nbHeurefrmSpecifique, condition, sanction, docMinistere, codeProgramme) VALUES
('2001','AA','91 2/3', 'Informatique de gestion', '660', '1980', 'Math�matique 526/Math�matique 536', 'Dipl�me d��tudes coll�giales', NULL, '420'),
('2000','A1',NULL,NULL,NULL,NULL,NULL,'Dipl�me d��tudes coll�giales',NULL,'582'),
('2001','A0',NULL,NULL,NULL,NULL,'Math�matique 536','Dipl�me d��tudes coll�giales',NULL,'180'),
('2000','C0',NULL,NULL,NULL,NULL,'Math�matique 526','Dipl�me d��tudes coll�giales',NULL,'210')
GO
--select * from EnteteProgramme
--select * from tblProgramme